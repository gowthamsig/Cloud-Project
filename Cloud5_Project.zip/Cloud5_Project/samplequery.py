#!/usr/bin/python
from __future__ import print_function # Python 2/3 compatibility
import boto3
import json
import decimal
import sys
from boto3.dynamodb.conditions import Key, Attr
#import requests
import botocore


# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

dynamodb = boto3.resource('dynamodb', region_name='us-east-1', endpoint_url="https://dynamodb.us-east-1.amazonaws.com")

table = dynamodb.Table('SalesData')


count = int(sys.argv[2])
name = str(sys.argv[1])
endDate= str(sys.argv[3])
currentDate= str(sys.argv[4])


#s=requests.Session() # creating a session
#login_data = dict(userName='subramanian.g', password='Pulsar180!') #login info

#ra=s.post('https://myneu.neu.edu/cp/home/displaylogin', data=login_data) # sending post request and storing in a repsonse

#Connecting to s3 and getting the bucket
s3 = boto3.resource('s3')
#bucket = s3.Bucket('cloudbucketproject')

#file = open('out.txt','w')
for num in range(0,count):
 fileName = str(name+'_'+str(num+1)+'.txt')
 s3.Object('cloudbucketproject', 'reports/'+fileName)
 print("Thread: %s execution value %d" % (name,num+1))
 print("------------------------------------------------------------------------------------------------------------------------------------------------")
 #file.write("Thread: %s execution value %d" % (name,num+1))
 #file.write("------------------------------------------------------------------------------------------------------------------------------------------------")
 response = table.query(
    ProjectionExpression="#vr, Order_Date, Row_ID, Order_ID, Order_Priority, Order_Quantity, Sales, Discount, Ship_Mode, Profit, Unit_Price, Shipping_Cost, Customer_Name, Province, Customer_Segment, Product_Category, Product_Sub_Category, Product_Name, Product_Container, Product_Base_Margin, Ship_Date",
    ExpressionAttributeNames={ "#vr": "Vendor" }, # Expression Attribute Names for Projection Expression only.
    KeyConditionExpression=Key('Vendor').eq('Amazon') & Key('Order_Date').between(endDate, currentDate)
 )
 #print(response)
 #itemcount = response[u'Count']
 #for num in range(1,itemcount+1)
 count = 0                       
 values = ""
 for i in response[u'Items']:
  count+=1
  #print(json.dumps(i, cls=DecimalEncoder))
  
  values+= (json.dumps(i, cls=DecimalEncoder))
  
 s3.Object('cloudbucketproject', 'reports/'+fileName).put(Body=values)
  #file.write(json.dumps(i, cls=DecimalEncoder))
#file.close()
#sys.exit(0)
#print("Value Count %d" % count)
#print (ra.headers)