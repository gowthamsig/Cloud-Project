package com.cloud5Project;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class JavaToPython {

	public static void button(int userCount, int reportCount, int days, String buttonName) {
		
		CountDownLatch countDownLatch;

		ExecutorService executorService;

		
		String endDate;
		String currentDate;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();

		

			countDownLatch = new CountDownLatch(userCount);
			executorService = Executors.newFixedThreadPool(userCount);
			

			Calendar cal = Calendar.getInstance();
			currentDate = dateFormat.format(date);
			cal.add(Calendar.DATE, -days);
			Date todate1 = cal.getTime();
			endDate = dateFormat.format(todate1);

			System.out.println(endDate + " " + currentDate);
			for (int i = 1; i <= userCount; i++) {
				executorService.submit(new JavaFetchPython(countDownLatch, i, reportCount, endDate, currentDate, buttonName));
			}

			try {
				countDownLatch.await();
				System.out.println("All the threads executed");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
	  
	}


}
