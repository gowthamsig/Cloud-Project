package com.cloud5Project;


import java.util.concurrent.CountDownLatch;

public class JavaFetchPython implements Runnable {

	private CountDownLatch latch;
	private int threadCount;
	private int reportCount;
	private String endDate;
	private String currentDate;
	private String button;

	public JavaFetchPython(CountDownLatch latch, int i, int count, String endDate, String currentDate, String buttonName) {
		// TODO Auto-generated constructor stub
		this.button= buttonName;
		this.latch = latch;
		threadCount = i;
		reportCount=count;
		this.endDate = endDate;
		this.currentDate = currentDate;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread.currentThread().setName(button  + "User" + threadCount);
		System.out.println("Executing Thread " + Thread.currentThread().getName());

		try {
			PythonWrapper wrapper = PythonWrapper.getInstance();
			wrapper.scriptInitializer(Thread.currentThread().getName(), reportCount, endDate, currentDate);
			Thread.sleep(30);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		latch.countDown();
	}

}
