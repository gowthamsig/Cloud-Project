package com.cloud5Project;

import java.security.GeneralSecurityException;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.DynamoDBEncryptor;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.EncryptionContext;
import com.amazonaws.services.dynamodbv2.datamodeling.encryption.providers.DirectKmsMaterialProvider;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.kms.AWSKMS;
import com.amazonaws.services.kms.AWSKMSClient;

/*
 * Copyright 2012-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
public class UserDatatoDynamoDB {
	private static final String Role = "Role";
	private static final String Username = "Username";
	private static final String Password = "Password";
	private static final String Full_Name = "Full_Name";
	private static final String EMAIL = "EMAIL";
	private static final String TABLE = "Users";
	final static AWSKMS kms = new AWSKMSClient();
	final static AmazonDynamoDB ddb = new AmazonDynamoDBClient();

	final static DynamoDB dynamoDB = new DynamoDB(ddb);

	static Table table = dynamoDB.getTable(TABLE);

	// Set up the aws-dynamodb-encryption-java library
	final static DynamoDBEncryptor cryptor = DynamoDBEncryptor
			.getInstance(new DirectKmsMaterialProvider(kms, "alias/Usersinfo"));
	// Despite the similar name, the DynamoDb EncryptionContext is used to guide
	// the DynamoDBEncryptor for key and algorithm selection (among other
	// things)
	// and not just for the KMS EncryptionContext (though it is used for that as
	// well).
	final static EncryptionContext ddbCtx = new EncryptionContext.Builder().withTableName(TABLE)
			.withHashKeyName(Username).build();

	public static void main(final String[] args) throws GeneralSecurityException {
		// Alice stores her address
		saveUser();
		// Mallory stores her address
		// saveUser("mallory@example.com",
		// "Mallory Evesdotir, 321 Evilstreed Ave., Despair, USA");

		// Output saved addresses
		// System.out.println("Alice's Address: " +
		// getAddress("alice@example.com"));
		// System.out.println("Mallory's Address: " +
		// getAddress("mallory@example.com"));

		// Mallory tampers with the database by swapping the encrypted
		// addresses.
		// Note that this doesn't require modifying the ciphertext at all.
		// First, retrieve the records from DynamoDB
		/*
		 * final Map<String, AttributeValue> mallorysRecord = ddb .getItem(
		 * TABLE, Collections.singletonMap(EMAIL, new
		 * AttributeValue().withS("mallory@example.com"))).getItem(); final
		 * Map<String, AttributeValue> alicesRecord = ddb.getItem(TABLE,
		 * Collections.singletonMap(EMAIL, new
		 * AttributeValue().withS("alice@example.com"))) .getItem();
		 */

		// Second, extract the encrypted addresses
		// final ByteBuffer mallorysEncryptedAddress =
		// mallorysRecord.get(ADDRESS).getB();
		// final ByteBuffer alicesEncryptedAddress =
		// alicesRecord.get(ADDRESS).getB();

		// Third, swap the encrypted addresses
		// mallorysRecord.put(ADDRESS, new
		// AttributeValue().withB(alicesEncryptedAddress));
		// alicesRecord.put(ADDRESS, new
		// AttributeValue().withB(mallorysEncryptedAddress));

		// Finally, store the encrypted addresses back in DynamoDB
		// ddb.putItem(TABLE, mallorysRecord);
		// ddb.putItem(TABLE, alicesRecord);

		// Now, when Alice tries to use her address we attempt to decrypt the
		// tampered data
		// get a SignatureException
		/*
		 * try { System.out.println("Alice's Address: " +
		 * getAddress("alice@example.com")); // Likewise, if Mallory tries to
		 * look up her address, she can view Alice's instead
		 * System.out.println("Mallory's Address: " +
		 * getAddress("mallory@example.com")); } catch (final SignatureException
		 * ex) { ex.printStackTrace(); }
		 */
	}

	private static void saveUser() throws GeneralSecurityException {
		final Map<String, AttributeValue> item = new HashMap<>();

		item.put(Role, new AttributeValue().withS("Admin"));
		item.put(Username, new AttributeValue().withS("gowtham"));
		item.put(Password, new AttributeValue().withS("Iagfc@5"));
		item.put(Full_Name, new AttributeValue().withS("Gowtham Subramanian"));
		item.put(EMAIL, new AttributeValue().withS("gowthamsig@gmail.com"));
		final Map<String, AttributeValue> encryptedItem = cryptor.encryptAllFieldsExcept(item, ddbCtx, Full_Name, EMAIL,
				Role, Username);

		ddb.putItem(TABLE, encryptedItem);
		System.out.println("added");

		// table.putItem(new
		// com.amazonaws.services.dynamodbv2.document.Item().withPrimaryKey(
		// Role, "Admin", Username,
		// "vimal").with(encryptedItem.keySet().toString(),
		// encryptedItem.values().toString()));
	}
}

/*
 * private static String getAddress(final String email) throws
 * GeneralSecurityException { final Map<String, AttributeValue> encryptedItem =
 * ddb.getItem(TABLE, Collections.singletonMap(EMAIL, new
 * AttributeValue().withS(email))).getItem(); final Map<String, AttributeValue>
 * item = cryptor.decryptAllFieldsExcept( encryptedItem, ddbCtx, EMAIL); return
 * item.get(ADDRESS).getS();
 * 
 * }
 */