package com.cloud5Project;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class PythonWrapper {

	private PythonWrapper() {

	}

	private static class PythonWrapperHolder {
		private static final PythonWrapper instance = new PythonWrapper();
	}

	public static PythonWrapper getInstance() {
		return PythonWrapperHolder.instance;
	}

	public void scriptInitializer(String name, int count, String endDate, String currentDate) {

		ProcessBuilder pb = new ProcessBuilder("python",
				"samplequery.py", name, String.valueOf(count), endDate,
				currentDate);
		pb.directory(new File("/etc/python2.7"));
		Process p = null;
		pb.redirectErrorStream(true);

		try {

			p = pb.start();

			/*
			 * BufferedReader rd = new BufferedReader(new
			 * InputStreamReader(p.getErrorStream())); String line =
			 * rd.readLine(); while (line != null) { System.out.println(line);
			 * line = rd.readLine(); }
			 */

			BufferedReader red = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String value = null;

			while ((value = red.readLine()) != null) {
				System.out.println(value);
			}

			p.waitFor();
			int exit = p.exitValue();
			System.out.println(exit);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			p.destroy();
		}

	}

}